import hashlib
import os
import argparse
import json

class FileIntegrityChecker:
    def __init__(self, hash_algo='sha256'):
        self.hash_algo = hash_algo

    def generate_hash(self, file_path):
        hash_func = getattr(hashlib, self.hash_algo)()
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b''):
                hash_func.update(chunk)
        return hash_func.hexdigest()

    def verify_file(self, file_path, expected_hash):
        file_hash = self.generate_hash(file_path)
        return file_hash == expected_hash

    def generate_manifest(self, directory, output_file='manifest.json'):
        manifest = {}
        for root, _, files in os.walk(directory):
            for name in files:
                file_path = os.path.join(root, name)
                manifest[file_path] = self.generate_hash(file_path)
        with open(output_file, 'w') as f:
            json.dump(manifest, f, indent=4)
        print(f"[+] Manifest saved as '{output_file}'.")

    def verify_manifest(self, manifest_file):
        with open(manifest_file, 'r') as f:
            manifest = json.load(f)
        results = {}
        for file_path, expected_hash in manifest.items():
            if os.path.exists(file_path):
                results[file_path] = self.verify_file(file_path, expected_hash)
            else:
                results[file_path] = False
        return results

def main():
    parser = argparse.ArgumentParser(description="🔐 File Integrity Checker Tool")
    parser.add_argument('--generate', help="Generate a manifest for a directory of files.")
    parser.add_argument('--verify', help="Verify file integrity using a manifest.json file.")
    parser.add_argument('--hash', default='sha256', help="Choose hash algorithm (e.g., sha256, sha1, md5)")
    args = parser.parse_args()

    checker = FileIntegrityChecker(hash_algo=args.hash)

    if args.generate:
        checker.generate_manifest(args.generate)
    elif args.verify:
        results = checker.verify_manifest(args.verify)
        for file, status in results.items():
            print(f"{file}: {'✅ OK' if status else '❌ CORRUPTED or MISSING'}")
    else:
        parser.print_help()

if __name__ == '__main__':
    main()
